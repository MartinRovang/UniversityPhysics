from Files.Boid import Boid
from Files.Hawk import Hawk
from Files.Obstacles import Obstacle
