﻿
                                      ███▄ ▄███▓ ▄▄▄     ▓██   ██▓ ██░ ██ ▓█████  ███▄ ▄███▓
                                     ▓██▒▀█▀ ██▒▒████▄    ▒██  ██▒▓██░ ██▒▓█   ▀ ▓██▒▀█▀ ██▒
                                     ▓██    ▓██░▒██  ▀█▄   ▒██ ██░▒██▀▀██░▒███   ▓██    ▓██░
                                     ▒██    ▒██ ░██▄▄▄▄██  ░ ▐██▓░░▓█ ░██ ▒▓█  ▄ ▒██    ▒██ 
                                     ▒██▒   ░██▒ ▓█   ▓██▒ ░ ██▒▓░░▓█▒░██▓░▒████▒▒██▒   ░██▒
░                                      ▒░   ░  ░ ▒▒   ▓▒█░  ██▒▒▒  ▒ ░░▒░▒░░ ▒░ ░░ ▒░   ░  ░  ░░ ░   ░   ░      ░   
       ░         ░        ░░ ░      ░  ░  ░   ░  ░       ░   
                     ░ ░                               
#                                     Made by Martin Soria Røvang, 07.04.2019                                                
#                                     Github: https://github.com/MartinRovang                                                #
#                                                                                                                            #                   #
#                 Developed for mandatory assignment INF-1400 Object orientented programming, University of Tromsø.           #
#################################################################################################################################

Introduction:

This project is a clone of the game Mayhem, a multiplayer shooter game.

How to run:
run python main.py in cmd from folder. (Need python 3.6+ to run)

Controls:

Player1:
w: boost
e: fire
a: rotate left
d: rotate right


Player2:
up key: boost
space: fire
left key: rotate left
right key: rotate right


Dependencies:
Python 3.6+
numpy 1.15.0

