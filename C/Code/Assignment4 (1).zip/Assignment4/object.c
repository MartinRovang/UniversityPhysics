#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "object.h"
#include <string.h>
#include <time.h>



// Create new object
object_t *CreateObject(SDL_Surface *screen, triangle_t *model, int numtriangles)
{
        //Tilfeldig hastighet
        float r = 0;
        float speedx = 51;
        while (speedx > 50) {
                r = time(NULL);
                speedx = (r/(rand() % 999999999));
        }
        //AVSLUTT tilfeldig hasitghet
        //pek til data struktur og alloker minne
        object_t *object = malloc(sizeof(object_t));
        object->model = malloc(sizeof(triangle_t) *numtriangles);
        //BALL INNFORMASJON
        object->screen = screen;
        //TIMER 5 sec (KOMMER ANN PÅ PC)
        object->ttl = 0;
        //Tilfeldig hastighet x
        object->speedx = speedx;
        object->speedy = speedx/2;
        object->scale = 0.1;
        object->tx = 60;
        object->ty = 70;
        object->numtriangles = numtriangles;
        //kopier minne
        memcpy(object->model, model, sizeof(triangle_t) *numtriangles);
        //return verdi
        return object;
}


// Free memory used by object
void DestroyObject(object_t *object)
{
        // Implement me
        //SLETT MODEL OG OBJEKT FRA MINNE
        free(object->model);
        free(object);

}


// Draw object on screen
void DrawObject(object_t *object)
{
        // Implement me
        //legger inn model informasjonen til objektet for å manipulere verdiene
        int i = 0;
        while (i < object->numtriangles) {
                object->model[i].ty = object->ty;
                object->model[i].scale = object->scale;
                object->model[i].tx = object->tx;
                object->model[i].rotation = object->rotation;
                DrawTriangle (object->screen, &object->model[i]);
                i++;
        }
}
