#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "list.h"
#include "teapot_data.h"
#include "sphere_data.h"
#include "object.h"

#define MIN(x,y) (x < y ? x : y)
#define MAX(x,y) (x > y ? x : y)

//Hvor mange baller som traff taket
int trafftak = 0;
//LAGRE LEADERBOARD
void skrivTilFil()
{
        char buffer1[250];
        FILE *fil;                // Peker til fil struktur
        fil = fopen("leaderboards.txt", "a");
        while (fgets(buffer1,250,fil) != NULL) {
                fprintf(fil, "%s\n",buffer1 );
        }
        fprintf(fil, "\nSCORE: %d BALLER TRAFF TAKET!",trafftak); // printer til fil
        fclose(fil);
}

void lesFraFil()
{
        char buffer[250];    // Buffer for å holde data fra filen
        FILE *fil;
        fil = fopen("leaderboards.txt", "r");
        printf("\nLEADERBOARDS");
        while (fgets(buffer, 250, fil) != NULL) {
                printf("%s", buffer);
        }
        printf("\tDETTE VAR DIN SCORE\n");
        fclose(fil);            // Lukker filen
}



// Clear screen by filling it with 0
void ClearScreen(SDL_Surface *screen)
{
        SDL_Rect rect;

        // Define a rectangle covering the entire screen
        rect.x = 0;
        rect.y = 0;
        rect.w = screen->w;
        rect.h = screen->h;

        // And fill screen with 0
        SDL_FillRect(screen, &rect, 0);
}


// Add some speed to an object
void AccelerateObject(object_t *a, float boost, float maxspeed)
{
        float s;
        float news;

        // Calculate lenght of speed vector
        s = sqrtf(a->speedx * a->speedx + a->speedy * a->speedy);

        // Boost speed
        news = s * boost;
        if (news < 0.0)
                news = 0.0;
        if (news > maxspeed)
                news = maxspeed;
        a->speedx *= news/s;
        a->speedy *= news/s;
}
const int MAX_OBJECTS_ON_SCREEN = 15;
const int NUM_START_OBJECTS = 5;
void AddToScreen(list_t *objects, SDL_Surface *screen, triangle_t *model, int numtriangles)
{
        if(list_size(objects) <= MAX_OBJECTS_ON_SCREEN) {
                object_t *object = CreateObject(screen, model, numtriangles);
                list_addfirst(objects, object);
        }
}

//Antall baller som blir spawna
int ballerspawned = 0;
int tekannerspawned = 0;
void BouncingBalls(SDL_Surface *screen)
{
        // Implement me
        //FOR Å KUNNE BRUKE SDL FUNKSJONER
        SDL_Event event;
        //JUSTERING AV HASTIGHETER VED TREFFING AV VEGGER
        const double adjust1 = 0.1, adjust2 = 0.6, adjust3 = -0.6;
        // Lag liste
        list_t *balls = list_create();
        // Lage iterator til listen
        list_iterator_t *iter = list_createiterator(balls);

        // 5 BALLER I LISTA
        while(list_size(balls) != NUM_START_OBJECTS) {
                AddToScreen(balls, screen, sphere_model, SPHERE_NUMTRIANGLES);
        }
        // LAG BALL
        object_t *ball = CreateObject(screen, sphere_model, SPHERE_NUMTRIANGLES);
        //RADIUSEN PÅ BALLEN EN PROSENT AV PIXLENE HVIS SCALE 0.1 = 10 % av y3
        const int radius = ball->scale*500;

        //CLEARSCREEN OG ITERATOR RESET
        while(1) {
                // Rydder skjermen
                ClearScreen(screen);
                //resetter iteratoren
                list_resetiterator(iter);
                //KNAPPER
                //GJØR DET MULIG Å BRUKE SDL FUNKSJONER
                while(SDL_PollEvent(&event)) {
                        switch(event.type) {
                        //VED TASTETRYKK, LAG BALL
                        case SDL_KEYDOWN:
                                //VED TASTETRYKK A
                                if (event.key.keysym.sym == SDLK_a) {
                                        AddToScreen(balls, screen, sphere_model, SPHERE_NUMTRIANGLES);
                                        ballerspawned++;
                                        break;
                                }
                                if (event.key.keysym.sym == SDLK_w) {
                                        AddToScreen(balls, screen, teapot_model, TEAPOT_NUMTRIANGLES);
                                        tekannerspawned++;
                                        break;
                                }
                        //AVSLUTT PROGRAM MED ESCAPE KNAPP
                        case SDL_QUIT:
                                if (event.key.keysym.sym == SDLK_ESCAPE) {
                                        //Renser opp og sletter hele lista
                                        printf("RENSER MINNE\n");
                                        list_destroy(balls);
                                        list_destroyiterator(iter);
                                        printf("ANTALL BALLER SOM TRAFF TAKET %d\n",trafftak );
                                        skrivTilFil();
                                        lesFraFil();
                                        exit(0);
                                }
                        }

                }
                //BALL I ITERATOR
                while ((ball = list_next(iter))) {
                        //Tegn ballen
                        DrawObject(ball);
                        //PHYSICS
                        // forandre posisjon i y retning
                        ball->ty += ball->speedy;
                        // forandre posisjon i x retning
                        ball->tx += ball->speedx;
                        // Gravitasjon
                        ball->speedy += 0.2;
                        // rotasjonen varierer etter hastigheten
                        ball->rotation += 1*ball->speedx;
                        // bakken, endre retning på hastigheten
                        //LITT TAP
                        if(ball->ty > screen->h - radius) {
                                ball->speedy *= -0.9;
                                //TREFFER BAKKEN
                                ball->ty = screen->h - radius;
                                //  printf("BAKKEN\n");
                        }
                        //TAK
                        if (ball->ty < 70) {
                                ball->ty = 70;
                                ball->speedy *= adjust3;
                                trafftak++;
                                printf("GRATULERER EN BALL TRAFF TAKET, DU HAR NÅ %d POENG!\n",trafftak);
                        }
                        // Venstrevegg med hastighetsjustering
                        if(ball->tx < radius) {
                                ball->speedx *= adjust3;
                                ball->speedx += adjust2;

                                //  printf("VENSTREVEGG\n");
                        }
                        // Høyrevegg med hastighetsjustering
                        if(ball->tx >= screen->w - radius) {
                                ball->speedx *= adjust3;
                                ball->speedx -= adjust2;
                        }
                        //Juster hastighet slik at det virker mer realistisk
                        if((ball->ty == screen->h - radius) && (ball->speedx < adjust1)) {
                                ball->speedx += adjust1;
                        }
                        if((ball->ty == screen->h - radius) && (ball->speedx > adjust1)) {
                                ball->speedx -= adjust1;
                                if(ball->speedx <= adjust1) {
                                        ball->speedx = 0;
                                        //printf("BALLEN STÅR STILLE\n");
                                        ball->speedy = 0;
                                }

                                //END PHYSICS
                        }
                        //START TIMER VED BALLSPEED = 0
                        if (ball->speedx == 0 && ball->ttl == 0) {
                                ball->ttl = SDL_GetTicks();
                        }
                        //SLETT BALL NÅR TIMER HAR BRUKT 5 SEKUNDER
                        if((SDL_GetTicks() >= (ball->ttl + 5000) && ball->ttl != 0)) {
                                //FJERN LISTA OG SLETT BALL
                                list_remove(balls,ball);
                                DestroyObject(ball);
                                //ERSTATT BALLER SOM SLETTES
                                AddToScreen(balls, screen, sphere_model, SPHERE_NUMTRIANGLES);
                        }
                }
                // Oppdater bildet
                SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
        }

}



// First function run in your program
int main(int argc, char **argv)
{
        int retval;
        SDL_Surface *screen;
        // Initialize SDL
        retval = SDL_Init(SDL_INIT_VIDEO);
        if (retval == -1) {
                printf("Unable to initialize SDL\n");
                exit(1);
        }

        // Create a 1024x768x32 window
        screen = SDL_SetVideoMode(1024, 768, 32, 0);
        if (screen == NULL) {
                printf("Unable to get video surface: %s\n", SDL_GetError());
                exit(1);
        }

        //tittel på programmet
        char tittel[50] = "PRESS A TO SPAWN BALL ||||| CLICK ESCAPE TO EXIT";
        SDL_WM_SetCaption(tittel, NULL);
        // Start bouncing some balls
        BouncingBalls(screen);
        // Shut down SDL
        SDL_Quit();

        // Wait a little bit jic something went wrong (so that printfs can be read)
        SDL_Delay(5000);

        return 0;
}
