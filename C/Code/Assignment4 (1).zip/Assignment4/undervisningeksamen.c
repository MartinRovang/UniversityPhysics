

int antallord(list_t *tekst)
{
list_iterator_t *iterator;
char *ord;
int antallOrd = 0;

iterator = list_createiterator(tekst);

ord = list_next(iterator);
while (ord != 0) {
  antallOrd++;
  ord = list_next(iterator);
}
list_destroyiterator(iterator);
return antallOrd;
}
