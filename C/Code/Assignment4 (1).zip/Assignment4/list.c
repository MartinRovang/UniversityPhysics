#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include <string.h>

/*
 * List implementation
 */

typedef struct listnode listnode_t;
struct listnode {
        listnode_t  *next;
        void        *item;
};

struct list {
        listnode_t *head;
        int numitems;
};

// Create new list
list_t *list_create(void)
{
        //allokere minneplasse
        list_t *newlist = malloc(sizeof(list_t));
        //sjekker om det er nok minne
        if (newlist == NULL) {
                printf("DET SKJEDDE EN FEIL\n");
                exit(1);
        }
        //rengjøre minneplasseringen
        newlist->head = NULL;
        newlist->numitems = 0;
        return newlist;
}


// Free list. items not freed.
void list_destroy(list_t *list)
{
        // Implement me
        //TØMMER LISTA
        free(list);
        printf("MINNE RENSET OK\n");
}


// Insert item first in list
int list_addfirst(list_t *list, void *item)
{
        // Implement me
        listnode_t *newnode = malloc(sizeof(listnode_t));
        if (newnode == NULL) {
                //returnerer feil
                printf("DET SKJEDDE EN FEIL\n");
        }
        newnode->item = item;
        //neste lenke skal bli første
        newnode->next = list->head;
        list->head = newnode;
        //ANTALL I LISTA
        list->numitems++;
        return 0;
}


// Insert item last in list.
int list_addlast(list_t *list, void *item)
{
        // Implement me
        listnode_t *newnode;
        listnode_t *tmp = list->head;
        //ALLOKER MINNE
        newnode = malloc(sizeof(listnode_t));
        newnode->item = item;
        newnode->next = NULL;
        if (tmp == NULL) {
                list->head = newnode;
        }
        else {
                while(tmp->next != NULL) {
                        tmp = tmp->next;
                }
                tmp->next = newnode;
                list->numitems++;
                //printf("ADDLAST\n" );
        }
        return 0;
}


// Remove item from list
void list_remove(list_t *list, void *item)
{

        //SLETT ITEM FØR NODE
        //SETT TIL TILBAKE TIL HEAD
        //leter i lista etter item
        listnode_t *tmp = list->head;
        if(tmp != NULL) {
                //Sjekker om den har funnet item
                if(tmp->item == item) {
                        list->head = tmp->next;
                        //FRIGJØR MINNE
                        free(tmp);
                }
                //FERDIG MED Å SLETTE ITEM, SLETT NODE
                if(tmp->next != NULL) {
                        while(tmp->next->item != item && tmp->next->next != NULL) {
                                //TIL NESTE NEXT
                                tmp = tmp->next;
                        }
                        //SLETTE NODEN
                        listnode_t *deletenode;
                        deletenode = tmp->next;
                        tmp->next = tmp->next->next;
                        //FRIGJØR NODE FRA MINNET
                        free(deletenode);
                        //trekk ifra lista
                        list->numitems--;
                }
        }
}


// Return # of items in list
int list_size(list_t *list)
{
        // Implement me
        return list->numitems;
}



/*
 * Iterator implementation
 */
struct list_iterator {
        listnode_t *next;
        list_t *list;
};


// Create new list iterator
list_iterator_t *list_createiterator(list_t *list)
{
        // Implement me
        //ALLOKER MINNE
        list_iterator_t *iterator = malloc(sizeof(list_iterator_t));
        iterator->next = list->head;
        iterator->list = list;
        return iterator;
}


// Free iterator
void list_destroyiterator(list_iterator_t *iter)
{
        // Implement me
        //tøm iter minne
        free(iter);
}


// Move iterator to next item in list and return current.
void *list_next(list_iterator_t *iter)
{
        // Implement me
        void *item = NULL;
        //hvis iter ikke er siste så skal den gå videre
        if (iter->next != NULL) {
                item = iter->next->item;
                iter->next = iter->next->next;
        }
        return item;
}


// Let iterator point to first item in list again
void list_resetiterator(list_iterator_t *iter)
{
        // Implement me
        //Tilbake til første node
        iter->next = iter->list->head;
}
