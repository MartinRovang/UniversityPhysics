#include <stdio.h>
#include <unistd.h>
#include <string.h>

// INTEGERS
int numlines;
int menuchoice;
int t;
int t1;
int number;
int primeFactor;
int startnum;
int endnum;
int x;
int j;
int k;
//INTEGERS



    void reverseString()
    {
      char string[100] = {'O', 'B', 'L', 'l', 'G', 'A', 'T', 'O','R','I','S','K','-','O','P','P','G','A','V','E','\0'}, temp;
      int i, j = 0;

      i = 0;
      j = strlen(string) - 1;

      printf("OBLIGATORISK-OPPGAVE will now be reversed!\n");
      printf("-----------------------------------------------\n");
      sleep(1);

      while (i < j)
      {
         temp = string[i];
         string[i] = string[j];
         string[j] = temp;
         i++;
         j--;
      }

      printf("\nReverse string is :%s", string);
    }

//Define log2  og log2 kalkulator

int myLog2(unsigned int n)
{
        printf("Log2 kalkulator, please enter a positive integer.\n");
        scanf("%d", &n);
        if (n==0) {
                printf("================================================\n");
                printf("log2 of 0 is undefined, please try another integer\n");
                printf("================================================\n");
                return 1;

        }


        // bruke digits for å runde av til helt tall
        else
        {
                int j = 0;
                int k = n;
                while(k > 1)
                {
                        //bitshift 1 mot høyre
                        k = (k >> 1);
                        j++;
                }
                printf("===================\n");
                printf("%d\n",j );
                printf("===================\n");
return 1;
        }

}

void myNumbers(int startnum, int endnum)
{

        //      int oddeven = myPrimeFactor(startnum,5);
        //    if(oddeven % 2 == 1) {}

        printf("\n");
        printf("==================");
        for (startnum; startnum <= endnum; startnum++) {
                printf("\n");
                if (startnum % 2 == 0) {
                        printf("%d is even and ",startnum);
                }
                else {
                        printf("%d is odd and ",startnum);
                }
                myPrimeFactor(startnum,5);
                if (startnum==endnum)
                {
                        printf("\n==================\n");
                }
        }
}


int myNumbersquest()
{
        printf("What number do you want to start with?\n");
        scanf("%d",&startnum );
        printf("What number do you want to end at?\n");
        scanf("%d",&endnum);
        myNumbers(startnum,endnum);
        return 1;
}


// Legg inn verdier for myprimeFactor

int Primefactquest()
{
        printf("\n");
        printf("What number do you want to find out is a prime factor?\n");
        scanf("%d",&number);
        printf("What is the prime factor?\n");
        scanf("%d",&primeFactor);
        myPrimeFactor(number,primeFactor);
return 1;
}

//Sjekke om tall har primfaktor til number

int myPrimeFactor(int number, int primeFactor)
{

                if (primeFactor % 2 == 0)
                {
                        printf("%d Is not a prime factor of %d!",primeFactor,number);
                        return 1;
                }
                else if (number % primeFactor == 0)
                {
                        printf("%d Is a prime factor of %d!",primeFactor,number);
                        return 1;

                }
                else if (number % primeFactor != 0)
                {
                        printf("%d Is not a prime factor of %d!",primeFactor,number);
                        return 1;
                }
        }

void myTriangles(int numlines)     //trekant funksjon
{

        printf("\n");
        printf("How big do you want the triangle?\n");
        scanf("%d",&numlines);
        for (t = 1; t <= numlines; t++) {    //t teller opp til numlines og legger på en * per runde
                printf("\n");                 // newspace for å legge stjernene nedover
                for (t1 = 1; t1 <= t; t1++) {
                        printf("*");

                }
        }
        printf("\n");
        printf("\n");
}


// MENY
int questions() {
        printf("\n");
        printf("\n==============================================\n");
        printf("\nWhat function do you want to run?\n");
        printf("\nType 1 for triangle function\n2 for prime factor\n3 for range/prime factor\n4 for log2 calculator\n5 for stringreverse\n0 to exit\n");
        printf("\n=============================================\n");

        scanf("%d",&menuchoice);
        if (menuchoice == 1) {
                myTriangles(0);
                questions();
        } else if (menuchoice == 2) {
                Primefactquest();
                questions();
        } else if (menuchoice == 3) {
                myNumbersquest();
                questions();
        } else if (menuchoice == 0) {
                return 0;
        }
        else if (menuchoice == 4) {
                myLog2(0);
                questions();
        }
        else if (menuchoice == 5) {
                reverseString(0);
                questions();
        }
        else {
                printf("Invalid option!, opening menu...\n");
                sleep(3);
                questions();
        }
        return -1;

}

int main()
{
        int retCode = questions();
        if(retCode == -1) {
                printf("There was an error");
                return -1;
        }
        if(retCode == 0) {
                return 0;
        }
        return 0;
}
