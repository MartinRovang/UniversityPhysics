#include <stdio.h>
#include <unistd.h>

int x,y ;                             // x og y skal være tall

int main() {

printf("Write a number: ");          // første del av oppgaven x variabel
if (scanf("%d",&x)!=1) {             // variablen skal skiftes ut med tall som brukeren velger, ved bruk av bokstaver kjører den i feil.
     printf("Invalid number, please try again. Program will now close\n");
sleep(3);          // pause
    return -1;
}

printf("Write a new number: ");     // andre del av oppgaven y variabel

if (scanf("%d",&y)!=1) {
     printf("Invalid number, please try again. Program will now close\n");
sleep(3);          //pause
     return -1;
}
if (x>y) {                          // enten er x større enn y eller ikke
  printf("The biggest number is %d\n", x);
sleep(3);         //pause
  return 1;
}
  else {                            // hvis forrige argument ikke var sann så kommer programmet hit
printf("The biggest number is %d\n", y);
sleep(3);           //pause
return 1;
}

 }
