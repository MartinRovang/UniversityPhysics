#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "object.h"


// Create new object
object_t *CreateObject(SDL_Surface *screen, triangle_t *model, int numtriangles)
{
    // Implement me
}


// Free memory used by object
void DestroyObject(object_t *object)
{
    // Implement me
}


// Draw object on screen
void DrawObject(object_t *object)
{
    // Implement me
} 
