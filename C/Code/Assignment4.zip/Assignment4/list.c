#include <stdio.h>
#include <stdlib.h>
#include "list.h"


/*
 * List implementation
 */
 
typedef struct listnode listnode_t;
struct listnode {
    listnode_t  *next;
    void        *item;
};

struct list {
    listnode_t *head;
    int numitems;
};


// Create new list
list_t *list_create(void)
{
    // Implement me
}

// Free list. items not freed.
void list_destroy(list_t *list)
{
    // Implement me
}


// Insert item first in list
int list_addfirst(list_t *list, void *item)
{
    // Implement me
}


// Insert item last in list.
int list_addlast(list_t *list, void *item)
{
    // Implement me
}


// Remove item from list
void list_remove(list_t *list, void *item)
{
    // Implement me
}


// Return # of items in list
int list_size(list_t *list)
{
    // Implement me
}



/*
 * Iterator implementation
 */
 

struct list_iterator {
    listnode_t *next;
    list_t *list;
};


// Create new list iterator
list_iterator_t *list_createiterator(list_t *list)
{
    // Implement me
}


// Free iterator
void list_destroyiterator(list_iterator_t *iter)
{
    // Implement me
}


// Move iterator to next item in list and return current.
void *list_next(list_iterator_t *iter)
{
    // Implement me
}


// Let iterator point to first item in list again
void list_resetiterator(list_iterator_t *iter)
{
    // Implement me
}




