#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "list.h"
#include "teapot_data.h"
#include "sphere_data.h"
#include "object.h"

#define MIN(x,y) (x < y ? x : y)
#define MAX(x,y) (x > y ? x : y)


// Clear screen by filling it with 0
void ClearScreen(SDL_Surface *screen)
{
    SDL_Rect rect;
    
    // Define a rectangle covering the entire screen
    rect.x = 0;
    rect.y = 0;
    rect.w = screen->w;
    rect.h = screen->h;
    
    // And fill screen with 0
    SDL_FillRect(screen, &rect, 0);
}


// Add some speed to an object
void AccelerateObject(object_t *a, float boost, float maxspeed)
{
    float s;
    float news;
    
    // Calculate lenght of speed vector
    s = sqrtf(a->speedx * a->speedx + a->speedy * a->speedy);

    // Boost speed
    news = s * boost;
    if (news < 0.0)
        news = 0.0;
    if (news > maxspeed)
        news = maxspeed;    
    a->speedx *= news/s;
    a->speedy *= news/s;
}


void BouncingBalls(SDL_Surface *screen)
{
    // Implement me
}


// First function run in your program
int main(int argc, char **argv)
{
    int retval;
    SDL_Surface *screen;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);
    }
    
    // Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

    // Start bouncing some balls
    BouncingBalls(screen);

    // Shut down SDL    
    SDL_Quit();

    // Wait a little bit jic something went wrong (so that printfs can be read)
    SDL_Delay(5000);
    
    return 0;
}
