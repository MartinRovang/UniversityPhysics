#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "drawline.h"
#include "triangle.h"
#include "teapot_data.h"






// First function run in your program
int main(int argc, char **argv)
{
    int retval, done;
    SDL_Surface *screen;
    SDL_Event event;

    // Initialize SDL
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);
    }

    //Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());
        exit(1);
    }

    // The teapot is represented as an array of triangle data structures.
    // To draw it on the screen you need to traverse the 'teapot_model' array
    // and call DrawTriangle for each triangle (teapot_data.h contains the array).
    // The definition TEAPOT_NUMTRIANGLES specifies the number of triangles in the array.
    // The teapot model is contained within a 1000x1000 box (coordinates
    // from -500 to 500 on the x and y axis).  Remember to translate the
    // model to the middle of the screen before drawing it (initialize
    // triangle->tx and triangle->ty with the appropriate coordinates).


    // Draw some example triangles on the screen.
    // Use these examples in the beginning.


    int i = 1;
    while (i < TEAPOT_NUMTRIANGLES) {
      DrawTriangle(screen, &teapot_model[i]);
      i++;
    }



    // Wait for ctrl-c from user
    done = 0;
    while (done == 0) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_QUIT:
                done = 1;
                break;
            }
        }
    }

    SDL_Quit();

    return 0;
}
