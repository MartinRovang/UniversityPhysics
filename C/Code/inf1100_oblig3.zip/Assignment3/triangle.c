#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "triangle.h"
#include "drawline.h"
#include <math.h>



#define TRIANGLE_PENCOLOR   0xBBBB0000





// Print triangle coordinates along with a message
void PrintTriangle(triangle_t *triangle, char *msg)
{
    printf("%s: %d,%d - %d,%d - %d,%d\n",
        msg,
        triangle->x1, triangle->y1,
        triangle->x2, triangle->y2,
        triangle->x3, triangle->y3);
}


// Return 0 if triangle coordinates are outside the screen boundary. 1 otherwise.
int SanityCheckTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    if (triangle->sx1 < 0 || triangle->sx1 >= screen->w ||
        triangle->sx2 < 0 || triangle->sx2 >= screen->w ||
        triangle->sx3 < 0 || triangle->sx3 >= screen->w ||
        triangle->sy1 < 0 || triangle->sy1 >= screen->h ||
        triangle->sy2 < 0 || triangle->sy2 >= screen->h ||
        triangle->sy3 < 0 || triangle->sy3 >= screen->h) {
        return 0;
    } else {
        return 1;
    }
}


// Scale triangle
void ScaleTriangle(triangle_t *triangle)
{
    // TODO: Replace the code below with code that scales each triangle coordinate.
    // The scaling factor is specified in triangle->scale.
    // Remember that this function MUST write to the on-screen coordinates.
    // Do not alter the model coordinates.


      //skift 1.0 med scaling faktoren man vil bruke.

      triangle->scale = 1.0;

      //scale opp trekant, bare endre SX og SY ikke x1 og y1
      triangle->sx1 = (triangle->x1*triangle->scale);
      triangle->sx2 = (triangle->x2*triangle->scale);
      triangle->sx3 = (triangle->x3*triangle->scale);
      triangle->sy1 = (triangle->y1*triangle->scale);
      triangle->sy2 = (triangle->y2*triangle->scale);
      triangle->sy3 = (triangle->y3*triangle->scale);


  }


// Move triangle to its screen position
void TranslateTriangle(triangle_t *triangle)
{
    // TODO: Insert code that moves the triangle on the screen.
    // The translation coordinates are specified in triangle->tx and triangle->ty.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)


    //sett opp for skjerm med oppløsning 1024x768
    // men siden skjermen er minimert til halvparten av fullscreen så må jeg dele det på 2.
    triangle->tx = 1024/2;
    triangle->ty = 768/2;

    //Koordinatene er orginalt utafor skjermen (negative fortegn) så de må plusses opp for å passe skjermen. den blir laget orginalt i origo i kartisiskesystem, mens pc kordinatsystemet ligger i 3 kvadrant.
    triangle->sx1 = (triangle->tx+triangle->sx1);
  	triangle->sx2 = (triangle->tx+triangle->sx2);
  	triangle->sx3 = (triangle->tx+triangle->sx3);
  	triangle->sy1 = (triangle->ty+triangle->sy1);
  	triangle->sy2 = (triangle->ty+triangle->sy2);
  	triangle->sy3 = (triangle->ty+triangle->sy3);
  }



// Calculate triangle bounding box
void CalculateTriangleBoundingBox(triangle_t *triangle)
{
    // TODO: Insert code that calculates the bounding box of a triangle.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)
    // The bounding box coordinates should be written to
    // triangle->bx, triangle->by, triangle->bw, triangle->bh
    // Calculate max value for x


        //definerer triangle for å forenkle kodingen
        float sx1 = triangle->sx1;
        float sx2 = triangle->sx2;
        float sx3 = triangle->sx3;
        float sy1 = triangle->sy1;
        float sy2 = triangle->sy2;
        float sy3 = triangle->sy3;

        //xmin
        triangle->bx = fminf(fminf(sx1,sx2),sx3);
        //xmax med tanke på differansen
        triangle->bw = fmaxf(fmaxf(sx1,sx2),sx3)-triangle->bx;
        //ymin
        triangle->by = fminf(fminf(sy1,sy2),sy3);
        //ymax med tanke på differansen
        triangle->bh = fmaxf(fmaxf(sy1,sy2),sy3)-triangle->by;


}




// Fill triangle with a color
void FillTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    // TODO: Insert code that fills the triangle with the color specified in triangle->fillcolor.
    // Hint: Draw the triangle with color TRIANGLE_PENCOLOR (this color can not
    // occur in e.g. the teapot or the example triangles).  Thus, if your
    // approach to filling the triangle relies on looking for the edges of
    // the triangle on the screen (via the GetPixel function), you will find those
    // edges even if the triangle overlaps with a triangle that has already
    // been drawn on the screen.



    //kordinater, ymin,xmin fra venstre. xmaks fra høyre med ymin.
    int ymin, xmin, xmax;
    //scan x og y fra venstre for TRIANGLE_PENCOLOR med differanse
        for (ymin = triangle->by; ymin <= (triangle->bh+triangle->by); ymin++){
          for (xmin = triangle->bx; xmin <= (triangle->bw+triangle->bx); xmin++){
            if (GetPixel(screen, xmin, ymin) == TRIANGLE_PENCOLOR) {
              break;
          }
        }
    //scan x og y fra høyre for TRIANGLE_PENCOLOR med differanse
        for (xmax = (triangle->bw+triangle->bx); xmax >= triangle->bx; xmax--){
          if (GetPixel(screen, xmax, ymin) == TRIANGLE_PENCOLOR) {
            break;
          }
        }
        //Fyll farge innafor trekanten
        DrawLine(screen, xmin,ymin,xmax,ymin, triangle->fillcolor);
      }
}

// Draw triangle on screen
void DrawTriangle(SDL_Surface *screen, triangle_t *triangle)
{
    int isOK;

    // Scale.
    ScaleTriangle(triangle);


    // Translate.
    TranslateTriangle(triangle);

    // Determine bounding box
    CalculateTriangleBoundingBox(triangle);

    // Sanity check that triangle is within screen boundaries.
    isOK = SanityCheckTriangle(screen, triangle);
    if (isOK == 0) {
        PrintTriangle(triangle, "Triangle outside screen boundaries");
        return;
    }

    // TODO: Insert calls to DrawLine to draw the triangle.
    // Remember to use the on-screen coordinates (triangle->sx1, etc.)

    //Tegn linjene til trekantene i alle punkter

      DrawLine(screen, triangle->sx1, triangle->sy1, triangle->sx2, triangle->sy2, TRIANGLE_PENCOLOR);
      DrawLine(screen, triangle->sx2, triangle->sy2, triangle->sx3, triangle->sy3, TRIANGLE_PENCOLOR);
      DrawLine(screen, triangle->sx1, triangle->sy1, triangle->sx3, triangle->sy3, TRIANGLE_PENCOLOR);

    // Fill triangle
    FillTriangle(screen, triangle);

    // Force screen update.
    SDL_UpdateRect(screen, triangle->bx, triangle->by, triangle->bw, triangle->bh);

    // Force update of entire screen.  Comment/remove this call and uncomment the above call
    // when your CalculateTriangleBoundingBox function has been implemented.
    //SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}
